package controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Team;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import utils.UiUtils;
import dao.PlayerDao;

public class LoginController implements Controller {
 private PlayerDao playerDao= null;
 
 public void setPlayerDao(PlayerDao playerDao) {
  this.playerDao = playerDao;
 }
 @RequestMapping(value="login.do",method=RequestMethod.POST)
@Override
public ModelAndView handleRequest(HttpServletRequest request,
		HttpServletResponse response) throws Exception {
	 String userId = UiUtils.toUnicode(request.getParameter("userId"));
	 String password= UiUtils.toUnicode(request.getParameter("password"));
	 System.out.println("id : " + userId);
	 System.out.println("passwd : " + password);
	 Team team = new Team();
	 team.setId(Integer.parseInt(userId));
	 team.setName(password);
	 playerDao.insertPlayer(team);
	 ModelAndView mv = new ModelAndView("hello");
	 mv.addObject("hello", "hello  " + userId + "��!");
	return mv;
}
 
 
 //POST��û�� ���� ó��
 

 

 
}
