package controller;

public class HelloSpring {
	public String sayHello(String name) {
		return "Hello " + name;
	}
}
