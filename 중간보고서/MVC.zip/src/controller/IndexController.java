package controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import logic.Shop;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import dao.TeamDao;

public class IndexController implements Controller {
	private Shop shopService;
	private TeamDao teamDao;
	
	public void setTeamDao(TeamDao teamDao) { this.teamDao = teamDao; }
	@Override
	public ModelAndView handleRequest(HttpServletRequest arg0,
			HttpServletResponse arg1) throws Exception {
		List itemList = this.teamDao.getTeamList();
		Map model = new HashMap();
		model.put("itemList", itemList);
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("index");
		modelAndView.addAllObjects(model);
		return modelAndView;
	}

}
