package logic;

import model.Team;

public interface UserInfo {
	String insertAll(Integer id, String name);
}
