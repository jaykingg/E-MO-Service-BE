package logic;

import java.util.List;

public interface Shop {
	List getItemList();
}
