package logic;

import java.sql.Types;

import javax.sql.DataSource;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.SqlUpdate;

import model.Team;
import dao.UserDao;

public class UserInfoImpl extends SqlUpdate implements UserInfo{
	public UserInfoImpl(DataSource ds)
	{
		super(ds, "INSERT INTO team (id, name) VALUES(?,?)");
		super.declareParameter(new SqlParameter("id", Types.INTEGER));
		super.declareParameter(new SqlParameter("name", Types.VARCHAR));
		compile();
	}

	@Override
	public String insertAll(Integer id, String name) {
		// TODO Auto-generated method stub
		return null;
	}

}
