package logic;

import java.util.List;

public class ShopImpl implements Shop{
	private ItemCatalog itemCatalog;
	public void setItemCatalog(ItemCatalog itemCatalog) {
		this.itemCatalog = itemCatalog;
	}
	@Override
	public List getItemList() {
		// TODO Auto-generated method stub
		return this.itemCatalog.getItemList();
	}

}
