package dao.impl;

import model.Team;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import dao.PlayerDao;

public class PlayerDaoImpl extends JdbcDaoSupport implements PlayerDao {
	private InsertPlayer insertPlayer;
	
	protected void initDao() throws Exception {
		this.insertPlayer = new InsertPlayer(getDataSource());
	}

	@Override
	public void insertPlayer(Team team) throws DataAccessException {
		// TODO Auto-generated method stub
		this.insertPlayer.update(new Object[] { team.getId(), team.getName()});
	}
	
}
