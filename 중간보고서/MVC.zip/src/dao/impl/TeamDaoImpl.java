package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import model.Team;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import dao.TeamDao;


public class TeamDaoImpl extends JdbcDaoSupport implements TeamDao {
	@Override
	public List getTeamList() throws DataAccessException {
		// TODO Auto-generated method stub
		RowMapper rowMapper = new TeamRowMapper();
		return getJdbcTemplate().query("SELECT id, name FROM team",
				rowMapper);

	}

	@Override
	public Team getTeam(Integer teamId) throws DataAccessException {
		// TODO Auto-generated method stub
		return null;
	}

	protected class TeamRowMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			// ResultSet���� ������Ʈ�� �ٽ� ä�� ����
			Team team = new Team();
			team.setId(rs.getInt("id"));
			team.setName(rs.getString("name"));
			return team;
		}
	}
}
