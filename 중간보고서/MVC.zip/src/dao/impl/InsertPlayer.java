package dao.impl;

import java.sql.Types;

import javax.sql.DataSource;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.SqlUpdate;

public class InsertPlayer extends SqlUpdate{
	public InsertPlayer(DataSource ds)
	{
		super(ds, "INSERT INTO team (id, name) VALUES(?,?)");
		super.declareParameter(new SqlParameter("id", Types.INTEGER));
		super.declareParameter(new SqlParameter("name", Types.VARCHAR));
		compile();
	}
}
