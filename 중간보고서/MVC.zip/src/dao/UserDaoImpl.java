package dao;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import logic.Item;
import model.Team;

import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;


public class UserDaoImpl extends JdbcDaoSupport implements UserDao {
	private static final String SELECT_ALL = "SELECT id, name FROM team";
	@SuppressWarnings("rawtypes")
	private class ItemRowMapper implements RowMapper {
		@Override
		public Object mapRow(ResultSet rs, int arg1) throws SQLException {
			Item item = new Item();
			item.setId(new Integer(rs.getInt(1)));
			item.setName(rs.getString(2));
			System.out.println("id = "+ item.getId());
			System.out.println("name= "+ item.getName());
			return item;
		}
	}
	@Override
	public Team checkLoginInfo(Integer userId, String password) {
		return (Team)getJdbcTemplate().query(UserDaoImpl.SELECT_ALL, new ItemRowMapper());
	}
	
}
