package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import logic.Item;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class ItemDaoImpl extends JdbcDaoSupport implements ItemDao {
	private static final String SELECT_ALL = "SELECT id, name FROM team";
	@SuppressWarnings("rawtypes")
	private class ItemRowMapper implements RowMapper {

		@Override
		public Object mapRow(ResultSet rs, int arg1) throws SQLException {
			Item item = new Item();
			item.setId(new Integer(rs.getInt(1)));
			item.setName(rs.getString(2));
			System.out.println("id = "+ item.getId());
			System.out.println("name= "+ item.getName());
			return item;
		}
		
	}
	@SuppressWarnings("unchecked")
	@Override
	public List findAll() {
		return getJdbcTemplate().query(ItemDaoImpl.SELECT_ALL, new ItemRowMapper());
	}

}
