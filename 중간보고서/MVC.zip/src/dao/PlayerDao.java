package dao;

import model.Team;

import org.springframework.dao.DataAccessException;

public interface PlayerDao {
	void insertPlayer(Team team)throws DataAccessException;
}
