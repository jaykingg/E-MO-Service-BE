package dao;

import model.Team;

public interface UserDao {
	Team checkLoginInfo(Integer userId, String password);
}
